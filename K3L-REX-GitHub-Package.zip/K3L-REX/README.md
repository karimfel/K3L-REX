# K3L – Karim 3-Level Logic & REX Logical Agent

### 🇫🇷 Présentation
K3L est un modèle de logique computationnelle à 3 états (N, P, A) conçu par **Fellouri Abdelkrim** (Karim).
Il permet une représentation plus riche que le binaire, adaptée à la mémoire, aux signaux, à la compression, et à l'intelligence artificielle logique.
**REX** est l'agent autonome issu de cette logique, capable de reconstruire, interpréter et raisonner en mode trinaire.

Ce dépôt est **public**, mais certaines fonctions sont volontairement restreintes pour des raisons de sécurité scientifique.
Merci de respecter cette confidentialité.

### 🇬🇧 Overview
**K3L (Karim 3-Level Logic)** is a trit-based computing model using three states: N (Null), P (Passive), and A (Active).
It enables rich representations for memory, signal modeling, compression, and logic-based AI.
**REX** is an autonomous agent built on K3L, capable of analyzing and reconstructing logical data.

### 📘 Détails
- Article HAL : [hal-05104397v1](https://hal.archives-ouvertes.fr/hal-05104397v1)
- Auteur : *Fellouri Abdelkrim* (aka Karim / Einstein23)
- Date : 10 juin 2025
- Contact : **+213673376404** (WhatsApp)

### ⚠️ Confidentialité
Ce projet contient uniquement les éléments ouverts.
Les éléments sensibles (structure ADN complète, mutations critiques, logique interne de sécurité) sont archivés hors ligne.
